import SwiftUI

import SwiftUI

struct CurrentView: View {
    //let backgroundGradient = LinearGradient(
    //colors: [Color.red, Color.blue],
    //startPoint: .top, endPoint: .bottom)
    @State var charge = 0.00
    @State var time = 0.00
    @State var resistance = 0.00
    @State var current = 0.00
    @State var current2 = 0.00
    @State var current3 = 0.00
    @State var chargeDensity = 0.00
    @State var crossSectionalArea = 0.00
    @State var driftVelocity = 0.00
    @State var voltage = 0.00
    @State var relativeChargeOfChargeCarriers = 0.00
    @State var resistivity = 0.00
    @State var lengthOfMaterial = 0.00
    var body: some View {
        ScrollView {
            ZStack{
                //backgroundGradient
            VStack{
            Text("Current unknown (I = nAvq)")
                .font(.title)
                .foregroundColor(.white)
            HStack {
                Text("Charge Density:")
                    .padding()
                    .foregroundColor(.white)
            TextField("Charge density of material", value: $chargeDensity, format: .number)
                .textFieldStyle(.roundedBorder)
                .padding(.all, 5)
                .background(.cyan)
            }
            HStack {
                Text("Drift Velocity:")
                    .padding()
                    .foregroundColor(.white)
            TextField("Drift velocity of charge carriers", value: $driftVelocity, format: .number)
                .textFieldStyle(.roundedBorder)
                .padding(.all, 5)
                .background(.black)
            }
            HStack {
                Text("Cross-Sectional Area:")
                    .padding()
                    .foregroundColor(.white)
            TextField("Cross-sectional area", value: $crossSectionalArea, format: .number)
                .textFieldStyle(.roundedBorder)
                .padding(.all, 5)
                .background(.red)
            }
            HStack {
                Text("Charge Of Carriers:")
                    .padding()
                    .foregroundColor(.white)
            TextField("Relative charge of charge carriers", value: $relativeChargeOfChargeCarriers, format: .number)
                .textFieldStyle(.roundedBorder)
                .padding(.all, 5)
                .background(.gray)
            }
            let current = chargeDensity*crossSectionalArea*driftVelocity*relativeChargeOfChargeCarriers
            HStack{
                Text("Current is")
                    .font(.title2)
                    .foregroundColor(.white)
                Text(String(current))
                    .bold()
                    .font(.title2)
                    .foregroundColor(.white)
                Text("A")
                    .bold()
                    .font(.title2)
                    .foregroundColor(.white)
            }
            VStack{
                Text("Current unknown (I = V/R)")
                    .font(.title)
                    .padding()
                    .padding()
                    .foregroundColor(.white)
                HStack {
                    Text("Voltage:")
                        .padding()
                        .foregroundColor(.white)
                TextField("Voltage across component", value: $voltage, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .padding(.all, 5)
                    .background(.gray)
                }
                HStack {
                    Text("Resistance:")
                        .padding()
                        .foregroundColor(.white)
                TextField("Resistance of component", value: $resistance, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .padding(.all, 5)
                    .background(.gray)
                }
                let current2 = voltage/resistance
                HStack {
                    Text("Current is")
                        .font(.title2)
                        .foregroundColor(.white)
                    Text(String(current2))
                        .bold()
                        .font(.title2)
                        .foregroundColor(.white)
                    Text("A")
                        .bold()
                        .font(.title2)
                        .foregroundColor(.white)
                }
            }
            VStack {
                Text("Current unknown (I = Q/t)")
                    .font(.title)
                    .padding()
                    .padding()
                    .foregroundColor(.white)
                HStack {
                    Text("Charge:")
                        .padding()
                        .foregroundColor(.white)
                TextField("Charge travelled through a point in the circuit", value: $charge, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .padding(.all, 5)
                    .background(.gray)
                }
                HStack {
                    Text("Time:")
                        .padding()
                        .foregroundColor(.white)
                TextField("Time taken", value: $time, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .padding(.all, 5)
                    .background(.gray)
                }
                let current3 = charge/time
                HStack{
                    Text("Current is")
                        .font(.title2)
                        .foregroundColor(.white)
                    Text(String(current3))
                        .bold()
                        .font(.title2)
                        .foregroundColor(.white)
                    Text("A")
                        .bold()
                        .font(.title2)
                        .foregroundColor(.white)
                }
            }
        }
        }
        }
        .background(Color.black)
    }  
}
