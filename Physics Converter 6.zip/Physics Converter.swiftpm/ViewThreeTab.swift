import SwiftUI
import AVFoundation

var topicCards: [[String]] = []
var bylineprac: [String] = []

class TTS {
    
    let synthesizer = AVSpeechSynthesizer()
    
    func speak(messages: String) {
        print("[TTS][Speak]\n\(messages)")
        
        let utterance = AVSpeechUtterance(string: messages)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        utterance.postUtteranceDelay = 0.005
        synthesizer.speak(utterance)
    }
    
}

let tts = TTS()

struct ViewThreeTab: View {
    //@AppStorage("topicchoose") var topicchoose: Double = 0.00 // saves value
    @AppStorage("forgotten") var forgotten: String = ""
    @State var topicchoose = 0.00
    @State var cardItem = "Slide"
    @State var cardDefinition = "To choose a topic"
    @State var DeckPlace = 0
    @State var CanSeeItem = true
    @State var CanSeeDef = true
    var body: some View {
        VStack(){
            Text("Card Deck")
                .font(.largeTitle)
            
            HStack(){
                Text(cardItem)
                    .frame(width: 400, height: 50)
                    .opacity(CanSeeItem ? 1 : 0)
                    .background(.mint)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .animation(.easeInOut(duration: 0.5), value: CanSeeItem)
                    .padding()
                    .font(.title2)
                Button(){
                    CanSeeItem.toggle()
                }
            label: {Image(systemName:CanSeeItem ? "eye" : "eye.fill")}
                Button("📢tts"){
                    tts.speak(messages: cardItem)
                }
                
            }
            HStack{
                Text(cardDefinition)
                    .frame(width: 400, height: 200)
                    .opacity(CanSeeDef ? 1 : 0)
                    .background(.mint)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .animation(.easeInOut(duration: 0.5), value: CanSeeDef)
                    .padding()
                    .font(.title2)
                Button{
                    CanSeeDef.toggle()
                }
            label: {Image(systemName:CanSeeDef ? "eye" : "eye.fill")}
                
                Button("📢tts"){
                    print(AVSpeechSynthesisVoice.speechVoices())
                    tts.speak(messages: cardDefinition)
                }
                
            }
            
            
            HStack{
                Button(){
                    if (forgotten.contains(cardDefinition)){
                        print("Already got that one.")
                    }
                    else{
                        forgotten+="\(cardItem)\t\(cardDefinition)\tCurriculum: \(topics[Int(topicchoose)])\n"
                        print(forgotten)
                    }
                    
                }
            label: {
                Label("Forgotten", systemImage: "person.crop.circle.badge.questionmark")}
                
                Text(" - ")
                
                Button("⬅️ Prev"){
                    if(DeckPlace>0){
                        DeckPlace-=1
                        cardItem=topicCards[DeckPlace][0]
                        cardDefinition = topicCards[DeckPlace][1]
                    }
                }
                Text(" - ")
                
                Button("➡️ Next"){
                    if (topicCards.count-1 > DeckPlace){
                        DeckPlace+=1
                        cardItem=topicCards[DeckPlace][0]
                        cardDefinition = topicCards[DeckPlace][1]
                    }
                    else if(topicCards.count > 0){
                        DeckPlace=0
                        cardItem=topicCards[DeckPlace][0]
                        cardDefinition = topicCards[DeckPlace][1]
                        
                    }
                    
                }
                
                Text(" - ")
                
                Button("🎲 Random"){
                    if(topicCards.count > 0){
                        DeckPlace = Int.random(in: 0...(topicCards.count-1))
                        cardItem=topicCards[DeckPlace][0]
                        cardDefinition = topicCards[DeckPlace][1]
                    }
                    else{
                        topicchoose = Double(Int.random(in:0...10))
                    }
                }
            }
            Button("practice forgotten items"){
                topicCards.removeAll()
                if(forgotten.count>3){ // Handles empty forgotten lists
                    
                    bylineprac = forgotten.components(separatedBy: "\n")
                    for i in bylineprac{
                        if(i.count>1){
                            topicCards.append(i.components(separatedBy: "\t"))
                        }
                    }
                    cardItem=topicCards[0][0]
                    cardDefinition = topicCards[0][1]
                    
                }
                else{
                    cardItem="Nothing forgotten"
                }
            }
            .buttonStyle(.borderedProminent)
            .foregroundColor(.white)
            .cornerRadius(15)
            .font(.title)
            .padding()
            
            Spacer()
            
            Slider(value: $topicchoose, in: 0...10, step:1) // Number of topics
                .onChange(of: topicchoose){newValue in 
                    topicCards.removeAll()
                    for term in glossary{
                        if(term[2].contains(topics[Int(topicchoose)])){
                            //print(term)
                            topicCards.append(term)
                        }
                    }
                    print(topicCards)
                    if(topicCards.count > 0){
                        cardItem = topicCards[0][0]
                        cardDefinition = topicCards[0][1]
                    }
                    
                }
            Text(topics[Int(topicchoose)])
            
        }
        
    }
}
