import SwiftUI

struct SUVATView: View {
    let backgroundGradient = LinearGradient(
        colors: [Color.red, Color.blue],
        startPoint: .top, endPoint: .bottom)
    @State var displacement = 0.00
    @State var initialVelocity = 0.00
    @State var finalVelocity = 0.00
    @State var acceleration = 0.00
    @State var time = 0.00
    var body: some View {
        ScrollView{
            ZStack{
                backgroundGradient
                VStack{
                    VStack {
                        Text("SUVAT")
                            .font(.title)
                        Text(" ")
                    
                        .font(.title2)
                        VStack {
                        Text("Displacement")
                                .font(.title2)
                        TextField("Displacement", value: $displacement, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .padding(.all, 5)
                            .background(.gray)
                    }
                        VStack {
                        Text("Initial Velocity")
                                .font(.title2)
                        TextField("Initial Velocity", value: $initialVelocity, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .padding(.all, 5)
                            .background(.black)
                    }
                        VStack {
                        Text("Final Velocity")
                                .font(.title2)
                        TextField("Final Velocity", value: $finalVelocity, format: .number)
                            .textFieldStyle(.roundedBorder)
                            .padding(.all, 5)
                            .background(.red)
                    }
                        VStack {
                            Text("Acceleration")
                                .font(.title2)
                            TextField("Acceleration", value: $acceleration, format: .number)
                                .textFieldStyle(.roundedBorder)
                                .padding(.all, 5)
                                .background(.red)
                        }
                        VStack {
                            Text("Time")
                                .font(.title2)
                            TextField("Time", value: $time, format: .number)
                                .textFieldStyle(.roundedBorder)
                                .padding(.all, 5)
                                .background(.red)
                        }
                    }
                    
                    Text("1.     v = u + at")
                        .padding(5)
                        .font(.title)
                    Text("2.     s = ut + 1/2(at^2)")
                        .padding(5)
                        .font(.title)
                    Text("3.     s = vt - 1/2(a*t^2)")
                        .padding(5)
                        .font(.title)
                    VStack {
                        Text("4.     s = 1/2(u + v)t")
                            .padding(5)
                            .font(.title)
                        Text("5.     v^2 = u^2 + 2as")
                            .padding(5)
                            .font(.title)
                    }
                    
                    if (displacement != 0.00 && initialVelocity != 0.00 && finalVelocity != 0.00) {
                        let acceleration = (finalVelocity*finalVelocity-initialVelocity*initialVelocity)/(2*displacement)
                        let time = 2*(displacement)/(initialVelocity+finalVelocity)
                        
                    }
                    //else if (displacement != 0.00 && acceleration != 0.00 && finalVelocity != 0.00) {
                        //let displacement = pow((finalVelocity*finalVelocity)-(2*acceleration*displacement), 0.5)
                        //let time = (finalVelocity+pow((finalVelocity*finalVelocity-2*acceleration*displacement), 0.5))/(acceleration)
                    //}
                    Text(String(time))
                        .font(.title)
                }
            }
        }
    }  
}
