import SwiftUI

let topics = ["Command Words",
              "1 Data Representation",
              "2 Data Transmission",
              "3 Hardware",
              "4 Software",
              "5 Internet and its uses",
              "6 Emerging Tech",
              "7 Problem Solving",
              "8 Programming",
              "9 Databases",
              "10 Boolean Logic"]
