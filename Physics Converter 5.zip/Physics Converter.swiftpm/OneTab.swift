import SwiftUI
var randdef = 0

struct ViewOneTab: View {@State var myterm:String=""
    @State var definition: String = ""
    @AppStorage("forgotten") var forgotten: String = ""
    @Environment(\.colorScheme) var colorScheme
    @State var isDarkMode = false
    
    @State var resistance = 0.00
    @State var current = 0.00
    @State var chargeDensity = 0.00
    @State var crossSectionalArea = 0.00
    @State var driftVelocity = 0.00
    @State var voltage = 0.00
    @State var relativeChargeOfChargeCarriers = 0.00
    @State var resistivity = 0.00
    @State var lengthOfMaterial = 0.00
    
    var body: some View {
        ScrollView{
            VStack {
                HStack {
                    Text("Search Glossary")
                        .font(.largeTitle)
                        .padding()
                    .padding(.trailing)
                }
                Text("Text is automatically copied to the pasteboard")
                
                HStack{
                    Image(systemName: "magnifyingglass")
                    TextField("word",text: $myterm)
                        .onSubmit {
                            definition = ""
                            for term in glossary{
                                if(term[0].lowercased().contains(myterm.lowercased())){
                                    definition += "\(term[0])\t\(term[1])\tCurriculum: \(term[2])\n"
                                }
                            }
                            UIPasteboard.general.string = definition
                            
                        }
                        .font(.title)
                    
                }
                .padding()
                
                HStack{
                    Button(){
                        if(forgotten.contains(definition)){
                            print("Already got that one")
                        }
                        else{
                            forgotten+=definition
                            print(forgotten)
                        }
                        
                    } label: {
                        Label("Forgotten", systemImage: "person.crop.circle.badge.questionmark")
                        .font(.title3)}
                    
                    Text(" - ")
                    
                    Button("🎲 Random")
                    {
                        randdef = Int.random(in: 1...(glossary.count-1))
                        myterm = glossary[randdef][0]
                        definition = "\(glossary[randdef][0])\t\(glossary[randdef][1]) \tCurriculum: \(glossary[randdef][2])\n"
                        UIPasteboard.general.string = definition
                        
                    }
                    .font(.title3)
                    Text(" - ")
                    
                    Button("📢 tts"){
                        tts.speak(messages: definition)
                    }
                    .font(.title3)
                }
                
                ScrollView([.vertical]) {
                    Text(definition)
                        .padding()
                }
                
                Spacer()
            }
        }
        .padding()
        .background(isDarkMode ? Color.black : Color.white)
        .foregroundColor(isDarkMode ? Color.white : Color.black)
        .preferredColorScheme(isDarkMode ? .dark : .light) // toggle dark mode
        .overlay(
            Button(action: {
                self.isDarkMode.toggle()
            }) {
                Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                    .font(.title)
                    .foregroundColor(isDarkMode ? .white : .primary)
            }
                .clipShape(Circle())
                .padding(16)
                .shadow(radius: 8)
            , alignment: .bottomTrailing)
    }
    
}
