import SwiftUI

struct ViewTwoTab: View {
    @State var isDarkMode = false
    var body: some View {
        VStack{
            Text("Glossary")
                .font(.title)
                .bold()
        }
        NavigationView {
            
            List{
                ForEach(glossary, id: \.self) { item in
                    NavigationLink(destination: Text("**\(item[0])**\n\(item[1]) \nCurric: \(item[2])")) {
                        Text(item[0])
                    }
                }
            }
            .padding()
            .background(isDarkMode ? Color.black : Color.white)
            .foregroundColor(isDarkMode ? Color.white : Color.black)
            .preferredColorScheme(isDarkMode ? .dark : .light)
            .overlay(
                Button(action: {
                    self.isDarkMode.toggle()
                }) {
                    Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                        .font(.title)
                        .foregroundColor(isDarkMode ? .white : .primary)
                }
                    .clipShape(Circle())
                    .padding(16)
                    .shadow(radius: 8)
                , alignment: .bottomTrailing)
        }
    }
}
